﻿namespace ExampleDotnetProject.Common;

public class Class1
{

}
